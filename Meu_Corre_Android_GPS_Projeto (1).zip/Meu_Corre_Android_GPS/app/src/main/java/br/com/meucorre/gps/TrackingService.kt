package br.com.meucorre.gps

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToLong

class TrackingService : Service(), LocationListener {
    companion object {
        const val ACTION_START = "br.com.meucorre.gps.START"
        const val ACTION_PAUSE = "br.com.meucorre.gps.PAUSE"
        const val ACTION_RESUME = "br.com.meucorre.gps.RESUME"
        const val ACTION_STOP = "br.com.meucorre.gps.STOP"
        private const val CHANNEL_ID = "meu_corre_tracking"
        private const val NOTIFICATION_ID = 701
    }

    private lateinit var locationManager: LocationManager
    private val prefs by lazy { getSharedPreferences("meu_corre_track", Context.MODE_PRIVATE) }
    private var lastLocation: Location? = null
    private var distanceMeters = 0.0
    private var elapsedBeforeSegment = 0L
    private var segmentStartedAt = 0L
    private var running = false
    private var points = JSONArray()

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
        restoreState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTracking(fresh = true)
            ACTION_RESUME -> startTracking(fresh = false)
            ACTION_PAUSE -> pauseTracking()
            ACTION_STOP -> stopTracking()
        }
        return START_STICKY
    }

    private fun restoreState() {
        distanceMeters = prefs.getFloat("distance_m", 0f).toDouble()
        elapsedBeforeSegment = prefs.getLong("elapsed_seconds", 0L) * 1000L
        points = try { JSONArray(prefs.getString("points", "[]")) } catch (_: Exception) { JSONArray() }
        running = prefs.getString("state", "Parado") == "Em andamento"
    }

    private fun startTracking(fresh: Boolean) {
        if (fresh) {
            distanceMeters = 0.0
            elapsedBeforeSegment = 0L
            points = JSONArray()
            lastLocation = null
            prefs.edit().clear().apply()
        }
        if (!hasLocationPermission()) {
            stopSelf()
            return
        }
        startForeground(NOTIFICATION_ID, buildNotification("GPS ativo — jornada em andamento"))
        running = true
        segmentStartedAt = SystemClock.elapsedRealtime()
        saveState("Em andamento")
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            var requested = false
            for (provider in providers) {
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestLocationUpdates(provider, 3000L, 5f, this)
                    requested = true
                }
            }
            if (!requested) updateNotification("Ative a localização do aparelho")
        } catch (_: SecurityException) {
            updateNotification("Permissão de localização não concedida")
        }
    }

    private fun pauseTracking() {
        if (!running) return
        elapsedBeforeSegment += SystemClock.elapsedRealtime() - segmentStartedAt
        running = false
        locationManager.removeUpdates(this)
        saveState("Pausado")
        updateNotification("Jornada pausada")
    }

    private fun stopTracking() {
        if (running) elapsedBeforeSegment += SystemClock.elapsedRealtime() - segmentStartedAt
        running = false
        locationManager.removeUpdates(this)
        saveState("Finalizado")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onLocationChanged(location: Location) {
        if (!running) return
        val previous = lastLocation
        if (previous != null) {
            val delta = previous.distanceTo(location).toDouble()
            // Filtra saltos improváveis e leituras de baixa precisão.
            if (delta in 1.0..500.0 && location.accuracy <= 50f) distanceMeters += delta
        }
        lastLocation = location
        points.put(JSONObject().apply {
            put("lat", location.latitude)
            put("lon", location.longitude)
            put("time", location.time)
            put("accuracy_m", location.accuracy)
            put("speed_mps", location.speed)
        })
        saveState("Em andamento")
        updateNotification("GPS ativo — %.2f km registrados".format(distanceMeters / 1000.0))
    }

    private fun saveState(state: String) {
        val elapsed = elapsedBeforeSegment + if (running) SystemClock.elapsedRealtime() - segmentStartedAt else 0L
        prefs.edit()
            .putString("state", state)
            .putFloat("distance_m", distanceMeters.toFloat())
            .putFloat("distance_km", (distanceMeters / 1000.0).toFloat())
            .putLong("elapsed_seconds", (elapsed / 1000L))
            .putString("points", points.toString())
            .apply()
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Rastreamento Meu Corre", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, TrackingService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 9, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Meu Corre")
            .setContentText(message)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Finalizar", pending)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("Deprecated in Android")
    override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        locationManager.removeUpdates(this)
        super.onDestroy()
    }
}
