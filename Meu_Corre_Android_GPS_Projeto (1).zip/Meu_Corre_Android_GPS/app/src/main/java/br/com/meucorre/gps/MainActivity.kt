package br.com.meucorre.gps

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            val p = getSharedPreferences("meu_corre_track", MODE_PRIVATE)
            val state = p.getString("state", "Parado")
            val km = p.getFloat("distance_km", 0f)
            val seconds = p.getLong("elapsed_seconds", 0L)
            status.text = "Status: $state"
            stats.text = "Distância: %.2f km\nTempo: %02d:%02d:%02d".format(
                km, seconds / 3600, (seconds % 3600) / 60, seconds % 60
            )
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF101114.toInt())
        }
        fun label(text: String, size: Float, color: Int): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }

        root.addView(label("MEU CORRE", 30f, 0xFFFFC928.toInt()))
        root.addView(label("Rastreamento da jornada", 18f, 0xFFFFFFFF.toInt()))
        status = label("Status: Parado", 18f, 0xFFFFFFFF.toInt())
        stats = label("Distância: 0,00 km\nTempo: 00:00:00", 22f, 0xFFFFFFFF.toInt())
        root.addView(status)
        root.addView(stats)

        fun addButton(caption: String, action: String) {
            val b = Button(this).apply {
                text = caption
                setOnClickListener { handleAction(action) }
            }
            root.addView(b)
        }
        addButton("INICIAR JORNADA", TrackingService.ACTION_START)
        addButton("PAUSAR", TrackingService.ACTION_PAUSE)
        addButton("RETOMAR", TrackingService.ACTION_RESUME)
        addButton("FINALIZAR E SALVAR", TrackingService.ACTION_STOP)
        root.addView(label(
            "O GPS só é coletado durante uma jornada iniciada por você. " +
            "A notificação informa quando o rastreamento está ativo.",
            13f, 0xFFBBBBBB.toInt()
        ))
        setContentView(root)
    }

    private fun handleAction(action: String) {
        if (action == TrackingService.ACTION_START && !hasLocationPermission()) {
            val permissions = arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            requestPermissions(permissions, 100)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        val intent = Intent(this, TrackingService::class.java).setAction(action)
        if (action == TrackingService.ACTION_START || action == TrackingService.ACTION_RESUME) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
        } else startService(intent)
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            handleAction(TrackingService.ACTION_START)
        } else if (requestCode == 100) {
            Toast.makeText(this, "Permissão de localização necessária para registrar o percurso.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() { super.onResume(); handler.post(refresh) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(refresh) }
}
