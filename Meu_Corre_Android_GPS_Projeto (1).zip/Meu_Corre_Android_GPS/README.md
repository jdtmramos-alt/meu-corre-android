# Meu Corre — módulo Android de rastreamento GPS

Projeto inicial Android Studio em Kotlin. Implementa:
- início, pausa, retomada e finalização da jornada;
- serviço Android em primeiro plano com notificação persistente;
- leitura de localização via `LocationManager`;
- distância acumulada com filtro simples de saltos;
- tempo decorrido, estado e pontos GPS persistidos localmente em `SharedPreferences`.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta `Meu_Corre_Android_GPS` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em aparelho Android físico com GPS.
5. Conceda a permissão de localização quando solicitada.
6. Toque em **INICIAR JORNADA** com o app aberto.

## Importante
- Este é o código-fonte de um módulo inicial, não um APK compilado.
- A execução em segundo plano usa serviço em primeiro plano e notificação persistente. O Android pode encerrar o processo em situações extremas; teste em diferentes aparelhos e versões.
- O app não solicita `ACCESS_BACKGROUND_LOCATION`: a jornada deve ser iniciada pelo usuário com o app visível. O serviço pode continuar ativo com o app em segundo plano enquanto permitido pelo Android.
- A captura automática de valores de Uber/99/inDrive não está incluída neste módulo.
- Os pontos GPS ficam no armazenamento privado do app. A interface de histórico, exportação GPX/CSV, mapa real, política de retenção e criptografia do banco devem ser adicionados antes de produção.
- Para publicação, revisar políticas do Google Play, texto de divulgação de localização, permissões e testes de consumo de bateria.
